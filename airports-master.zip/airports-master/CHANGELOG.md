## 1.3
- Added support for [venomous-freemode](https://github.com/FiveM-Scripts/venomous-freemode)

## 1.2
- Fixed the conflict where players would always spawn at the LSIA entrance when using any plane in the airport zone.
- Fixed the conflict where players could not get killed by pedestrians or other players after leaving the plane.

## 1.1
- Essentialmode isn't required by default, server admins can enable this option in **config.lua**.

## 1.0
- Added support for NativeUILua.
- Added support for EssentialMode.
- Added blips for **Los Santos International Airport** and **Sandy Shores Airfield.**
- Players can travel from **Los Santos International Airport** to **Sandy Shores Airfield.**.
