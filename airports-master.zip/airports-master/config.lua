config = {
   plane_model = "nimbus",
   use_essentialmode = false,
   use_venomous = true,
   moneyCurrency = "$",
   ticketPrice = 80
}